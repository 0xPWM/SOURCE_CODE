#ifndef PM_SIMD_MATH_H
#define PM_SIMD_MATH_H

/*
 * Shared double-precision SIMD math kernels: exp / log / log1p / sigmoid / logit.
 *
 * Two flavors built from the same polynomial data:
 *   - NEON (aarch64): 2-wide, always available at compile time.
 *   - AVX-512 (x86_64): 8-wide, requires avx512f + avx512dq at runtime;
 *     callers must be compiled with PM_SIMD_TARGET_AVX512 and dispatch manually.
 *
 * Accuracy: ~1-2 ulp for exp/sigmoid, ~2-3 ulp for log/log1p/logit across the
 * domains used by the kernel (probabilities clamped to [1e-12, 1 - 1e-12]).
 *
 * Domain notes:
 *   - pm_*_exp_pd clamps its argument to [-700, 700], which keeps the 2^n
 *     exponent-bit scaling in the normal range. Sigmoid saturates to its
 *     clamp bounds far earlier, so the clamp is invisible to callers.
 *   - pm_*_log_pd assumes finite normal positive input.
 *   - pm_*_log1p_pd assumes z > -1.
 *   - NaN inputs propagate as NaN (unlike the scalar libm-based fallbacks,
 *     which resolve NaN through fmin/fmax to a clamp bound).
 */

#include <stdint.h>

#define PM_SIMD_EPS 1e-12
#define PM_SIMD_ONE_MINUS_EPS (1.0 - 1e-12)

#define PM_SIMD_LOG2E 1.44269504088896340736e+00
#define PM_SIMD_LN2_HI 6.93147180369123816490e-01
#define PM_SIMD_LN2_LO 1.90821492927058770002e-10
#define PM_SIMD_EXP_CLAMP 700.0

/* Taylor coefficients 1/n! for exp(r), r in [-0.3466, 0.3466]. */
#define PM_EXP_C2 5.00000000000000000000e-01
#define PM_EXP_C3 1.66666666666666666666e-01
#define PM_EXP_C4 4.16666666666666666666e-02
#define PM_EXP_C5 8.33333333333333333333e-03
#define PM_EXP_C6 1.38888888888888888888e-03
#define PM_EXP_C7 1.98412698412698412698e-04
#define PM_EXP_C8 2.48015873015873015873e-05
#define PM_EXP_C9 2.75573192239858906525e-06
#define PM_EXP_C10 2.75573192239858906525e-07
#define PM_EXP_C11 2.50521083854417187750e-08
#define PM_EXP_C12 2.08767569878680989792e-09
#define PM_EXP_C13 1.60590438368216145993e-10

/* atanh series coefficients 2/n for log(m) = 2*atanh((m-1)/(m+1)). */
#define PM_LOG_C3 6.66666666666666666666e-01
#define PM_LOG_C5 4.00000000000000000000e-01
#define PM_LOG_C7 2.85714285714285714285e-01
#define PM_LOG_C9 2.22222222222222222222e-01
#define PM_LOG_C11 1.81818181818181818181e-01
#define PM_LOG_C13 1.53846153846153846153e-01
#define PM_LOG_C15 1.33333333333333333333e-01
#define PM_LOG_C17 1.17647058823529411764e-01
#define PM_LOG_C19 1.05263157894736842105e-01

/* Bit pattern of sqrt(0.5): mantissa-normalization pivot for log. */
#define PM_SIMD_SQRT_HALF_BITS 0x3FE6A09E667F3BCDLL

#if defined(__aarch64__) && (defined(__GNUC__) || defined(__clang__))
#define PM_SIMD_HAS_NEON 1
#else
#define PM_SIMD_HAS_NEON 0
#endif

#if (defined(__x86_64__) || defined(__i386__)) && (defined(__GNUC__) || defined(__clang__))
#define PM_SIMD_HAS_AVX512 1
#define PM_SIMD_TARGET_AVX512 __attribute__((target("avx512f,avx512dq")))
#else
#define PM_SIMD_HAS_AVX512 0
#define PM_SIMD_TARGET_AVX512
#endif

#if PM_SIMD_HAS_NEON

#include <arm_neon.h>

static inline float64x2_t pm_neon_exp_pd(float64x2_t x) {
    const float64x2_t v_one = vdupq_n_f64(1.0);

    x = vminq_f64(vdupq_n_f64(PM_SIMD_EXP_CLAMP), vmaxq_f64(vdupq_n_f64(-PM_SIMD_EXP_CLAMP), x));

    const int64x2_t n_i = vcvtnq_s64_f64(vmulq_f64(x, vdupq_n_f64(PM_SIMD_LOG2E)));
    const float64x2_t n_f = vcvtq_f64_s64(n_i);

    float64x2_t r = vfmsq_f64(x, n_f, vdupq_n_f64(PM_SIMD_LN2_HI));
    r = vfmsq_f64(r, n_f, vdupq_n_f64(PM_SIMD_LN2_LO));

    /* Estrin evaluation: ~5 FMA of depth instead of 12 for a Horner chain. */
    const float64x2_t r2 = vmulq_f64(r, r);
    const float64x2_t r4 = vmulq_f64(r2, r2);

    const float64x2_t b0 = vfmaq_f64(vdupq_n_f64(PM_EXP_C2), vdupq_n_f64(PM_EXP_C3), r);
    const float64x2_t b1 = vfmaq_f64(vdupq_n_f64(PM_EXP_C4), vdupq_n_f64(PM_EXP_C5), r);
    const float64x2_t b2 = vfmaq_f64(vdupq_n_f64(PM_EXP_C6), vdupq_n_f64(PM_EXP_C7), r);
    const float64x2_t b3 = vfmaq_f64(vdupq_n_f64(PM_EXP_C8), vdupq_n_f64(PM_EXP_C9), r);
    const float64x2_t b4 = vfmaq_f64(vdupq_n_f64(PM_EXP_C10), vdupq_n_f64(PM_EXP_C11), r);
    const float64x2_t b5 = vfmaq_f64(vdupq_n_f64(PM_EXP_C12), vdupq_n_f64(PM_EXP_C13), r);

    const float64x2_t c0 = vfmaq_f64(b0, b1, r2);
    const float64x2_t c1 = vfmaq_f64(b2, b3, r2);
    const float64x2_t c2 = vfmaq_f64(b4, b5, r2);

    const float64x2_t q = vfmaq_f64(c0, vfmaq_f64(c1, c2, r4), r4);
    float64x2_t p = vfmaq_f64(vaddq_f64(v_one, r), r2, q);

    const int64x2_t p_bits = vaddq_s64(vreinterpretq_s64_f64(p), vshlq_n_s64(n_i, 52));
    return vreinterpretq_f64_s64(p_bits);
}

static inline float64x2_t pm_neon_sigmoid_pd(float64x2_t x) {
    const float64x2_t v_one = vdupq_n_f64(1.0);

    const float64x2_t e = pm_neon_exp_pd(vnegq_f64(vabsq_f64(x)));
    const float64x2_t inv = vdivq_f64(v_one, vaddq_f64(v_one, e));

    const uint64x2_t non_negative = vcgeq_f64(x, vdupq_n_f64(0.0));
    float64x2_t p = vbslq_f64(non_negative, inv, vmulq_f64(e, inv));

    p = vmaxq_f64(vdupq_n_f64(PM_SIMD_EPS), vminq_f64(vdupq_n_f64(PM_SIMD_ONE_MINUS_EPS), p));
    return p;
}

static inline float64x2_t pm_neon_log_pd(float64x2_t x) {
    const float64x2_t v_one = vdupq_n_f64(1.0);

    const int64x2_t ix = vreinterpretq_s64_f64(x);
    const int64x2_t off = vsubq_s64(ix, vdupq_n_s64(PM_SIMD_SQRT_HALF_BITS));
    const int64x2_t e_i = vshrq_n_s64(off, 52);
    const float64x2_t m = vreinterpretq_f64_s64(vsubq_s64(ix, vshlq_n_s64(e_i, 52)));
    const float64x2_t e_f = vcvtq_f64_s64(e_i);

    const float64x2_t s = vdivq_f64(vsubq_f64(m, v_one), vaddq_f64(m, v_one));
    const float64x2_t w = vmulq_f64(s, s);

    float64x2_t t = vdupq_n_f64(PM_LOG_C19);
    t = vfmaq_f64(vdupq_n_f64(PM_LOG_C17), t, w);
    t = vfmaq_f64(vdupq_n_f64(PM_LOG_C15), t, w);
    t = vfmaq_f64(vdupq_n_f64(PM_LOG_C13), t, w);
    t = vfmaq_f64(vdupq_n_f64(PM_LOG_C11), t, w);
    t = vfmaq_f64(vdupq_n_f64(PM_LOG_C9), t, w);
    t = vfmaq_f64(vdupq_n_f64(PM_LOG_C7), t, w);
    t = vfmaq_f64(vdupq_n_f64(PM_LOG_C5), t, w);
    t = vfmaq_f64(vdupq_n_f64(PM_LOG_C3), t, w);

    float64x2_t res = vfmaq_f64(vmulq_f64(vmulq_f64(s, w), t), e_f, vdupq_n_f64(PM_SIMD_LN2_LO));
    res = vfmaq_f64(res, vdupq_n_f64(2.0), s);
    res = vfmaq_f64(res, e_f, vdupq_n_f64(PM_SIMD_LN2_HI));
    return res;
}

static inline float64x2_t pm_neon_log1p_pd(float64x2_t z) {
    const float64x2_t v_one = vdupq_n_f64(1.0);

    const float64x2_t w = vaddq_f64(v_one, z);
    const float64x2_t c = vsubq_f64(z, vsubq_f64(w, v_one));
    const float64x2_t l = pm_neon_log_pd(w);
    return vfmaq_f64(l, c, vdivq_f64(v_one, w));
}

static inline float64x2_t pm_neon_logit_pd(float64x2_t p) {
    const float64x2_t v_one = vdupq_n_f64(1.0);

    p = vmaxq_f64(vdupq_n_f64(PM_SIMD_EPS), vminq_f64(vdupq_n_f64(PM_SIMD_ONE_MINUS_EPS), p));
    const float64x2_t num = vsubq_f64(vaddq_f64(p, p), v_one);
    const float64x2_t z = vdivq_f64(num, vsubq_f64(v_one, p));
    return pm_neon_log1p_pd(z);
}

#endif /* PM_SIMD_HAS_NEON */

#if PM_SIMD_HAS_AVX512

#include <cpuid.h>
#include <immintrin.h>

/* Manual CPUID + XGETBV detection: no dependency on compiler-rt's
   __cpu_model (which rustc does not link on some platforms), and it checks
   that the OS actually saves the ZMM/opmask state. */
static inline int pm_simd_detect_avx512(void) {
    unsigned int eax = 0u, ebx = 0u, ecx = 0u, edx = 0u;

    if (!__get_cpuid(1u, &eax, &ebx, &ecx, &edx)) {
        return 0;
    }
    if ((ecx & (1u << 27)) == 0u) { /* OSXSAVE */
        return 0;
    }

    unsigned int xcr0_lo = 0u, xcr0_hi = 0u;
    __asm__ volatile("xgetbv" : "=a"(xcr0_lo), "=d"(xcr0_hi) : "c"(0u));
    (void)xcr0_hi;
    if ((xcr0_lo & 0xE6u) != 0xE6u) { /* XMM + YMM + opmask + ZMM state */
        return 0;
    }

    if (!__get_cpuid_count(7u, 0u, &eax, &ebx, &ecx, &edx)) {
        return 0;
    }
    const unsigned int avx512f = (ebx >> 16) & 1u;
    const unsigned int avx512dq = (ebx >> 17) & 1u;
    return (avx512f && avx512dq) ? 1 : 0;
}

PM_SIMD_TARGET_AVX512
static inline __m512d pm_avx512_exp_pd(__m512d x) {
    const __m512d v_one = _mm512_set1_pd(1.0);

    x = _mm512_min_pd(_mm512_set1_pd(PM_SIMD_EXP_CLAMP),
                      _mm512_max_pd(_mm512_set1_pd(-PM_SIMD_EXP_CLAMP), x));

    const __m512i n_i = _mm512_cvtpd_epi64(_mm512_mul_pd(x, _mm512_set1_pd(PM_SIMD_LOG2E)));
    const __m512d n_f = _mm512_cvtepi64_pd(n_i);

    __m512d r = _mm512_fnmadd_pd(n_f, _mm512_set1_pd(PM_SIMD_LN2_HI), x);
    r = _mm512_fnmadd_pd(n_f, _mm512_set1_pd(PM_SIMD_LN2_LO), r);

    __m512d q = _mm512_set1_pd(PM_EXP_C13);
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C12));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C11));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C10));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C9));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C8));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C7));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C6));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C5));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C4));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C3));
    q = _mm512_fmadd_pd(q, r, _mm512_set1_pd(PM_EXP_C2));

    const __m512d r2 = _mm512_mul_pd(r, r);
    const __m512d p = _mm512_fmadd_pd(r2, q, _mm512_add_pd(v_one, r));

    const __m512i p_bits =
        _mm512_add_epi64(_mm512_castpd_si512(p), _mm512_slli_epi64(n_i, 52));
    return _mm512_castsi512_pd(p_bits);
}

PM_SIMD_TARGET_AVX512
static inline __m512d pm_avx512_sigmoid_pd(__m512d x) {
    const __m512d v_one = _mm512_set1_pd(1.0);

    const __m512d e = pm_avx512_exp_pd(_mm512_sub_pd(_mm512_setzero_pd(), _mm512_abs_pd(x)));
    const __m512d inv = _mm512_div_pd(v_one, _mm512_add_pd(v_one, e));

    const __mmask8 negative = _mm512_cmp_pd_mask(x, _mm512_setzero_pd(), _CMP_LT_OQ);
    __m512d p = _mm512_mask_mul_pd(inv, negative, e, inv);

    p = _mm512_max_pd(_mm512_set1_pd(PM_SIMD_EPS),
                      _mm512_min_pd(_mm512_set1_pd(PM_SIMD_ONE_MINUS_EPS), p));
    return p;
}

PM_SIMD_TARGET_AVX512
static inline __m512d pm_avx512_log_pd(__m512d x) {
    const __m512d v_one = _mm512_set1_pd(1.0);

    const __m512i ix = _mm512_castpd_si512(x);
    const __m512i off = _mm512_sub_epi64(ix, _mm512_set1_epi64(PM_SIMD_SQRT_HALF_BITS));
    const __m512i e_i = _mm512_srai_epi64(off, 52);
    const __m512d m = _mm512_castsi512_pd(_mm512_sub_epi64(ix, _mm512_slli_epi64(e_i, 52)));
    const __m512d e_f = _mm512_cvtepi64_pd(e_i);

    const __m512d s = _mm512_div_pd(_mm512_sub_pd(m, v_one), _mm512_add_pd(m, v_one));
    const __m512d w = _mm512_mul_pd(s, s);

    __m512d t = _mm512_set1_pd(PM_LOG_C19);
    t = _mm512_fmadd_pd(t, w, _mm512_set1_pd(PM_LOG_C17));
    t = _mm512_fmadd_pd(t, w, _mm512_set1_pd(PM_LOG_C15));
    t = _mm512_fmadd_pd(t, w, _mm512_set1_pd(PM_LOG_C13));
    t = _mm512_fmadd_pd(t, w, _mm512_set1_pd(PM_LOG_C11));
    t = _mm512_fmadd_pd(t, w, _mm512_set1_pd(PM_LOG_C9));
    t = _mm512_fmadd_pd(t, w, _mm512_set1_pd(PM_LOG_C7));
    t = _mm512_fmadd_pd(t, w, _mm512_set1_pd(PM_LOG_C5));
    t = _mm512_fmadd_pd(t, w, _mm512_set1_pd(PM_LOG_C3));

    __m512d res = _mm512_fmadd_pd(e_f, _mm512_set1_pd(PM_SIMD_LN2_LO),
                                  _mm512_mul_pd(_mm512_mul_pd(s, w), t));
    res = _mm512_fmadd_pd(_mm512_set1_pd(2.0), s, res);
    res = _mm512_fmadd_pd(e_f, _mm512_set1_pd(PM_SIMD_LN2_HI), res);
    return res;
}

PM_SIMD_TARGET_AVX512
static inline __m512d pm_avx512_log1p_pd(__m512d z) {
    const __m512d v_one = _mm512_set1_pd(1.0);

    const __m512d w = _mm512_add_pd(v_one, z);
    const __m512d c = _mm512_sub_pd(z, _mm512_sub_pd(w, v_one));
    const __m512d l = pm_avx512_log_pd(w);
    return _mm512_fmadd_pd(c, _mm512_div_pd(v_one, w), l);
}

PM_SIMD_TARGET_AVX512
static inline __m512d pm_avx512_logit_pd(__m512d p) {
    const __m512d v_one = _mm512_set1_pd(1.0);

    p = _mm512_max_pd(_mm512_set1_pd(PM_SIMD_EPS),
                      _mm512_min_pd(_mm512_set1_pd(PM_SIMD_ONE_MINUS_EPS), p));
    const __m512d num = _mm512_sub_pd(_mm512_add_pd(p, p), v_one);
    const __m512d z = _mm512_div_pd(num, _mm512_sub_pd(v_one, p));
    return pm_avx512_log1p_pd(z);
}

#endif /* PM_SIMD_HAS_AVX512 */

#endif /* PM_SIMD_MATH_H */
