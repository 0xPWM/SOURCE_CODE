#include "kernel.h"
#include "pm_simd_math.h"

#include <math.h>
#include <stdatomic.h>
#include <stdint.h>

#if PM_SIMD_HAS_AVX512
#define PM_KERNEL_HAS_AVX512_DISPATCH 1
#else
#define PM_KERNEL_HAS_AVX512_DISPATCH 0
#endif

#define PM_KERNEL_TARGET_AVX512 PM_SIMD_TARGET_AVX512

#if defined(__GNUC__) || defined(__clang__)
#define KERNEL_UNROLL_4 _Pragma("GCC unroll 4")
#else
#define KERNEL_UNROLL_4
#endif

static const double KERNEL_EPS = 1e-12;
static const double KERNEL_ONE_MINUS_EPS = 1.0 - 1e-12;

static inline double kernel_clamp(double v, double lo, double hi) {
    return fmin(hi, fmax(lo, v));
}

static inline double kernel_sigmoid_exact(double x) {
    const double e = exp(-fabs(x));
    const double inv = 1.0 / (1.0 + e);
    const double p = (x >= 0.0) ? inv : (e * inv);
    return kernel_clamp(p, KERNEL_EPS, KERNEL_ONE_MINUS_EPS);
}

#if PM_KERNEL_HAS_AVX512_DISPATCH
static _Atomic int kernel_has_avx512_cache = -1;

static inline int kernel_runtime_has_avx512(void) {
    int cached = atomic_load_explicit(&kernel_has_avx512_cache, memory_order_relaxed);
    if (cached >= 0) {
        return cached;
    }

    const int has_avx512 = pm_simd_detect_avx512();

    atomic_store_explicit(&kernel_has_avx512_cache, has_avx512, memory_order_relaxed);
    return has_avx512;
}
#endif

double kernel_sigmoid(double x) {
    return kernel_sigmoid_exact(x);
}

double kernel_logit(double p) {
    const double pc = kernel_clamp(p, KERNEL_EPS, KERNEL_ONE_MINUS_EPS);
    /* log1p((2p - 1) / (1 - p)) == log(p / (1 - p)), but 2p - 1 is exact for
       p in [0.25, 1], so the result keeps full relative accuracy near p = 0.5. */
    return log1p(((2.0 * pc) - 1.0) / (1.0 - pc));
}

void pm_internal_sigmoid_batch_portable(const double *x, double *out_p, size_t n) {
    KERNEL_UNROLL_4
    for (size_t i = 0u; i < n; ++i) {
        out_p[i] = kernel_sigmoid_exact(x[i]);
    }
}

void pm_internal_logit_batch_portable(const double *p, double *out_x, size_t n) {
    KERNEL_UNROLL_4
    for (size_t i = 0u; i < n; ++i) {
        out_x[i] = kernel_logit(p[i]);
    }
}

void pm_internal_greeks_batch_portable(const double *x, greek_out_t *out, size_t n) {
    KERNEL_UNROLL_4
    for (size_t i = 0u; i < n; ++i) {
        kernel_greeks_from_logit(x[i], &out[i].delta_x, &out[i].gamma_x);
    }
}

#if PM_SIMD_HAS_NEON

void pm_internal_sigmoid_batch_neon(const double *x, double *out_p, size_t n) {
    size_t i = 0u;
    for (; (i + 1u) < n; i += 2u) {
        vst1q_f64(out_p + i, pm_neon_sigmoid_pd(vld1q_f64(x + i)));
    }
    if (i < n) {
        out_p[i] = kernel_sigmoid_exact(x[i]);
    }
}

void pm_internal_logit_batch_neon(const double *p, double *out_x, size_t n) {
    size_t i = 0u;
    for (; (i + 1u) < n; i += 2u) {
        vst1q_f64(out_x + i, pm_neon_logit_pd(vld1q_f64(p + i)));
    }
    if (i < n) {
        out_x[i] = kernel_logit(p[i]);
    }
}

void pm_internal_greeks_batch_neon(const double *x, greek_out_t *out, size_t n) {
    const float64x2_t v_one = vdupq_n_f64(1.0);
    const float64x2_t v_two = vdupq_n_f64(2.0);

    size_t i = 0u;
    for (; (i + 1u) < n; i += 2u) {
        const float64x2_t p = pm_neon_sigmoid_pd(vld1q_f64(x + i));
        const float64x2_t delta = vmulq_f64(p, vsubq_f64(v_one, p));
        const float64x2_t gamma = vmulq_f64(delta, vfmsq_f64(v_one, v_two, p));

        /* greek_out_t is a pair of doubles: interleave delta/gamma per market. */
        const float64x2_t lane0 = vzip1q_f64(delta, gamma);
        const float64x2_t lane1 = vzip2q_f64(delta, gamma);
        vst1q_f64(&out[i].delta_x, lane0);
        vst1q_f64(&out[i + 1u].delta_x, lane1);
    }
    if (i < n) {
        kernel_greeks_from_logit(x[i], &out[i].delta_x, &out[i].gamma_x);
    }
}

void pm_internal_calculate_quotes_logit_neon(
    const double *x_t,
    const double *q_t,
    const double *sigma_b,
    const double *gamma,
    const double *tau,
    const double *k,
    double *bid_p,
    double *ask_p,
    size_t n
) {
    const float64x2_t v_zero = vdupq_n_f64(0.0);
    const float64x2_t v_half = vdupq_n_f64(0.5);
    const float64x2_t v_eps = vdupq_n_f64(KERNEL_EPS);

    const float64x2_t v_one = vdupq_n_f64(1.0);

    size_t i = 0u;
    /* 4 markets per iteration: two independent 2-wide lanes keep more exp/log
       dependency chains in flight than the out-of-order window alone. */
    for (; (i + 3u) < n; i += 4u) {
        float64x2_t r_x_u[2];
        float64x2_t delta_x_u[2];

        for (size_t u = 0u; u < 2u; ++u) {
            const size_t j = i + (2u * u);
            const float64x2_t x = vld1q_f64(x_t + j);
            const float64x2_t q = vld1q_f64(q_t + j);
            const float64x2_t sigma = vld1q_f64(sigma_b + j);
            const float64x2_t gamma_v = vmaxq_f64(v_zero, vld1q_f64(gamma + j));
            const float64x2_t tau_v = vmaxq_f64(v_zero, vld1q_f64(tau + j));
            const float64x2_t k_v = vmaxq_f64(v_eps, vld1q_f64(k + j));

            const float64x2_t sigma2 = vmulq_f64(sigma, sigma);
            const float64x2_t risk_term = vmulq_f64(gamma_v, vmulq_f64(sigma2, tau_v));
            r_x_u[u] = vfmsq_f64(x, q, risk_term);

            /* One reciprocal of k serves both gamma / k and the final / k. */
            const float64x2_t rk = vdivq_f64(v_one, k_v);
            const float64x2_t non_linear =
                vmulq_f64(pm_neon_log1p_pd(vmulq_f64(gamma_v, rk)), rk);
            delta_x_u[u] = vfmaq_f64(non_linear, v_half, risk_term);
        }

        for (size_t u = 0u; u < 2u; ++u) {
            const size_t j = i + (2u * u);
            vst1q_f64(bid_p + j, pm_neon_sigmoid_pd(vsubq_f64(r_x_u[u], delta_x_u[u])));
            vst1q_f64(ask_p + j, pm_neon_sigmoid_pd(vaddq_f64(r_x_u[u], delta_x_u[u])));
        }
    }

    for (; (i + 1u) < n; i += 2u) {
        const float64x2_t x = vld1q_f64(x_t + i);
        const float64x2_t q = vld1q_f64(q_t + i);
        const float64x2_t sigma = vld1q_f64(sigma_b + i);
        const float64x2_t gamma_v = vmaxq_f64(v_zero, vld1q_f64(gamma + i));
        const float64x2_t tau_v = vmaxq_f64(v_zero, vld1q_f64(tau + i));
        const float64x2_t k_v = vmaxq_f64(v_eps, vld1q_f64(k + i));

        const float64x2_t sigma2 = vmulq_f64(sigma, sigma);
        const float64x2_t risk_term = vmulq_f64(gamma_v, vmulq_f64(sigma2, tau_v));
        const float64x2_t r_x = vfmsq_f64(x, q, risk_term);

        const float64x2_t rk = vdivq_f64(v_one, k_v);
        const float64x2_t non_linear =
            vmulq_f64(pm_neon_log1p_pd(vmulq_f64(gamma_v, rk)), rk);
        const float64x2_t delta_x = vfmaq_f64(non_linear, v_half, risk_term);

        vst1q_f64(bid_p + i, pm_neon_sigmoid_pd(vsubq_f64(r_x, delta_x)));
        vst1q_f64(ask_p + i, pm_neon_sigmoid_pd(vaddq_f64(r_x, delta_x)));
    }

    for (; i < n; ++i) {
        const double gamma_s = fmax(0.0, gamma[i]);
        const double tau_s = fmax(0.0, tau[i]);
        const double k_s = fmax(KERNEL_EPS, k[i]);

        const double risk_term = gamma_s * sigma_b[i] * sigma_b[i] * tau_s;
        const double r_x = x_t[i] - (q_t[i] * risk_term);
        const double delta_x = (0.5 * risk_term) + (log1p(gamma_s / k_s) / k_s);

        bid_p[i] = kernel_sigmoid_exact(r_x - delta_x);
        ask_p[i] = kernel_sigmoid_exact(r_x + delta_x);
    }
}

#endif /* PM_SIMD_HAS_NEON */

#if PM_KERNEL_HAS_AVX512_DISPATCH

PM_KERNEL_TARGET_AVX512
void pm_internal_sigmoid_batch_avx512(const double *x, double *out_p, size_t n) {
    size_t i = 0u;
    for (; (i + 7u) < n; i += 8u) {
        _mm512_storeu_pd(out_p + i, pm_avx512_sigmoid_pd(_mm512_loadu_pd(x + i)));
    }
    pm_internal_sigmoid_batch_portable(x + i, out_p + i, n - i);
}

PM_KERNEL_TARGET_AVX512
void pm_internal_logit_batch_avx512(const double *p, double *out_x, size_t n) {
    size_t i = 0u;
    for (; (i + 7u) < n; i += 8u) {
        _mm512_storeu_pd(out_x + i, pm_avx512_logit_pd(_mm512_loadu_pd(p + i)));
    }
    pm_internal_logit_batch_portable(p + i, out_x + i, n - i);
}

PM_KERNEL_TARGET_AVX512
void pm_internal_greeks_batch_avx512(const double *x, greek_out_t *out, size_t n) {
    const __m512d v_one = _mm512_set1_pd(1.0);
    const __m512d v_two = _mm512_set1_pd(2.0);

    size_t i = 0u;
    for (; (i + 7u) < n; i += 8u) {
        const __m512d p = pm_avx512_sigmoid_pd(_mm512_loadu_pd(x + i));
        const __m512d delta = _mm512_mul_pd(p, _mm512_sub_pd(v_one, p));
        const __m512d gamma = _mm512_mul_pd(delta, _mm512_fnmadd_pd(v_two, p, v_one));

        double delta_buf[8];
        double gamma_buf[8];
        _mm512_storeu_pd(delta_buf, delta);
        _mm512_storeu_pd(gamma_buf, gamma);
        for (size_t lane = 0u; lane < 8u; ++lane) {
            out[i + lane].delta_x = delta_buf[lane];
            out[i + lane].gamma_x = gamma_buf[lane];
        }
    }
    pm_internal_greeks_batch_portable(x + i, out + i, n - i);
}

#endif /* PM_KERNEL_HAS_AVX512_DISPATCH */

void kernel_sigmoid_batch(const double *x, double *out_p, size_t n) {
    if (x == NULL || out_p == NULL || n == 0u) {
        return;
    }

#if PM_SIMD_HAS_NEON
    pm_internal_sigmoid_batch_neon(x, out_p, n);
    return;
#else
#if PM_KERNEL_HAS_AVX512_DISPATCH
    if (kernel_runtime_has_avx512()) {
        pm_internal_sigmoid_batch_avx512(x, out_p, n);
        return;
    }
#endif
    pm_internal_sigmoid_batch_portable(x, out_p, n);
#endif
}

void kernel_logit_batch(const double *p, double *out_x, size_t n) {
    if (p == NULL || out_x == NULL || n == 0u) {
        return;
    }

#if PM_SIMD_HAS_NEON
    pm_internal_logit_batch_neon(p, out_x, n);
    return;
#else
#if PM_KERNEL_HAS_AVX512_DISPATCH
    if (kernel_runtime_has_avx512()) {
        pm_internal_logit_batch_avx512(p, out_x, n);
        return;
    }
#endif
    pm_internal_logit_batch_portable(p, out_x, n);
#endif
}

void kernel_greeks_from_logit(double x, double *delta_x, double *gamma_x) {
    if (delta_x == NULL || gamma_x == NULL) {
        return;
    }

    const double p = kernel_sigmoid_exact(x);
    const double delta = p * (1.0 - p);
    const double gamma = delta * (1.0 - (2.0 * p));

    *delta_x = delta;
    *gamma_x = gamma;
}

void kernel_greeks_batch(const double *x, greek_out_t *out, size_t n) {
    if (x == NULL || out == NULL || n == 0u) {
        return;
    }

#if PM_SIMD_HAS_NEON
    pm_internal_greeks_batch_neon(x, out, n);
    return;
#else
#if PM_KERNEL_HAS_AVX512_DISPATCH
    if (kernel_runtime_has_avx512()) {
        pm_internal_greeks_batch_avx512(x, out, n);
        return;
    }
#endif
    pm_internal_greeks_batch_portable(x, out, n);
#endif
}

void pm_internal_calculate_quotes_logit_portable(
    const double *x_t,
    const double *q_t,
    const double *sigma_b,
    const double *gamma,
    const double *tau,
    const double *k,
    double *bid_p,
    double *ask_p,
    size_t n
) {
    if (x_t == NULL || q_t == NULL || sigma_b == NULL || gamma == NULL || tau == NULL || k == NULL ||
        bid_p == NULL || ask_p == NULL || n == 0u) {
        return;
    }

    KERNEL_UNROLL_4
    for (size_t i = 0u; i < n; ++i) {
        const double gamma_v = fmax(0.0, gamma[i]);
        const double tau_v = fmax(0.0, tau[i]);
        const double k_v = fmax(KERNEL_EPS, k[i]);

        const double sigma2 = sigma_b[i] * sigma_b[i];
        const double variance_horizon = sigma2 * tau_v;
        const double risk_term = gamma_v * variance_horizon;
        const double r_x = x_t[i] - (q_t[i] * risk_term);

        const double delta_x = (0.5 * risk_term) + (log1p(gamma_v / k_v) / k_v);
        const double bid_x = r_x - delta_x;
        const double ask_x = r_x + delta_x;

        bid_p[i] = kernel_sigmoid_exact(bid_x);
        ask_p[i] = kernel_sigmoid_exact(ask_x);
    }
}

#if PM_KERNEL_HAS_AVX512_DISPATCH
PM_KERNEL_TARGET_AVX512
void pm_internal_calculate_quotes_logit_avx512(
    const double *x_t,
    const double *q_t,
    const double *sigma_b,
    const double *gamma,
    const double *tau,
    const double *k,
    double *bid_p,
    double *ask_p,
    size_t n
) {
    if (x_t == NULL || q_t == NULL || sigma_b == NULL || gamma == NULL || tau == NULL || k == NULL ||
        bid_p == NULL || ask_p == NULL || n == 0u) {
        return;
    }

    const __m512d v_zero = _mm512_set1_pd(0.0);
    const __m512d v_half = _mm512_set1_pd(0.5);
    const __m512d v_eps = _mm512_set1_pd(KERNEL_EPS);

    size_t i = 0u;
    for (; (i + 7u) < n; i += 8u) {
        const __m512d x = _mm512_loadu_pd(x_t + i);
        const __m512d q = _mm512_loadu_pd(q_t + i);
        const __m512d sigma = _mm512_loadu_pd(sigma_b + i);
        const __m512d gamma_v = _mm512_max_pd(v_zero, _mm512_loadu_pd(gamma + i));
        const __m512d tau_v = _mm512_max_pd(v_zero, _mm512_loadu_pd(tau + i));
        const __m512d k_v = _mm512_max_pd(v_eps, _mm512_loadu_pd(k + i));

        const __m512d sigma2 = _mm512_mul_pd(sigma, sigma);
        const __m512d risk_term = _mm512_mul_pd(gamma_v, _mm512_mul_pd(sigma2, tau_v));
        const __m512d r_x = _mm512_fnmadd_pd(q, risk_term, x);

        /* One reciprocal of k serves both gamma / k and the final / k. */
        const __m512d rk = _mm512_div_pd(_mm512_set1_pd(1.0), k_v);
        const __m512d non_linear =
            _mm512_mul_pd(pm_avx512_log1p_pd(_mm512_mul_pd(gamma_v, rk)), rk);
        const __m512d delta_x = _mm512_fmadd_pd(v_half, risk_term, non_linear);

        _mm512_storeu_pd(bid_p + i, pm_avx512_sigmoid_pd(_mm512_sub_pd(r_x, delta_x)));
        _mm512_storeu_pd(ask_p + i, pm_avx512_sigmoid_pd(_mm512_add_pd(r_x, delta_x)));
    }

    pm_internal_calculate_quotes_logit_portable(
        x_t + i, q_t + i, sigma_b + i, gamma + i, tau + i, k + i, bid_p + i, ask_p + i, n - i
    );
}
#endif

void calculate_quotes_logit(
    const double *x_t,
    const double *q_t,
    const double *sigma_b,
    const double *gamma,
    const double *tau,
    const double *k,
    double *bid_p,
    double *ask_p,
    size_t n
) {
#if PM_SIMD_HAS_NEON
    if (x_t == NULL || q_t == NULL || sigma_b == NULL || gamma == NULL || tau == NULL || k == NULL ||
        bid_p == NULL || ask_p == NULL || n == 0u) {
        return;
    }
    pm_internal_calculate_quotes_logit_neon(x_t, q_t, sigma_b, gamma, tau, k, bid_p, ask_p, n);
    return;
#else
#if PM_KERNEL_HAS_AVX512_DISPATCH
    if (kernel_runtime_has_avx512()) {
        pm_internal_calculate_quotes_logit_avx512(x_t, q_t, sigma_b, gamma, tau, k, bid_p, ask_p, n);
        return;
    }
#endif
    pm_internal_calculate_quotes_logit_portable(x_t, q_t, sigma_b, gamma, tau, k, bid_p, ask_p, n);
#endif
}
