#include "analytics.h"
#include "pm_simd_math.h"

#include <math.h>
#include <stdatomic.h>
#include <stdint.h>

#if PM_SIMD_HAS_AVX512
#define PM_ANALYTICS_HAS_AVX512_DISPATCH 1
#else
#define PM_ANALYTICS_HAS_AVX512_DISPATCH 0
#endif

#define PM_ANALYTICS_TARGET_AVX512 PM_SIMD_TARGET_AVX512

#if defined(__GNUC__) || defined(__clang__)
#define ANALYTICS_UNROLL_4 _Pragma("GCC unroll 4")
#else
#define ANALYTICS_UNROLL_4
#endif

static const double ANALYTICS_EPS = 1e-12;
static const double ANALYTICS_ONE_MINUS_EPS = 1.0 - 1e-12;
static const double ANALYTICS_DIV_EPS = 1e-9;

static _Atomic int analytics_has_avx512_cache = -1;

static inline double analytics_clamp(double v, double lo, double hi) {
    return fmin(hi, fmax(lo, v));
}

static inline int analytics_runtime_has_avx512(void) {
    int cached = atomic_load_explicit(&analytics_has_avx512_cache, memory_order_relaxed);
    if (cached >= 0) {
        return cached;
    }

    int has_avx512 = 0;

#if PM_ANALYTICS_HAS_AVX512_DISPATCH
    has_avx512 = pm_simd_detect_avx512();
#endif

    atomic_store_explicit(&analytics_has_avx512_cache, has_avx512, memory_order_relaxed);
    return has_avx512;
}

/*
 * The quoted spread in logit space is exactly
 *   spread = gamma * sigma^2 * tau + 2 * log1p(gamma / k) / k,
 * so the calibration inverts in closed form:
 *   sigma = sqrt((spread - 2 * log1p(gamma / k) / k) / (gamma * tau)).
 * No iterative refinement is needed.
 */
void pm_internal_implied_belief_volatility_batch_portable(
    const double *bid_p,
    const double *ask_p,
    const double *q_t,
    const double *gamma,
    const double *tau,
    const double *k,
    double *out_sigma_b,
    size_t n
) {
    if (bid_p == NULL || ask_p == NULL || gamma == NULL || tau == NULL || k == NULL || out_sigma_b == NULL || n == 0u) {
        return;
    }

    (void)q_t;

    ANALYTICS_UNROLL_4
    for (size_t i = 0u; i < n; ++i) {
        const double bid = analytics_clamp(bid_p[i], ANALYTICS_EPS, ANALYTICS_ONE_MINUS_EPS);
        const double ask = analytics_clamp(ask_p[i], ANALYTICS_EPS, ANALYTICS_ONE_MINUS_EPS);
        const double gamma_v = fmax(0.0, gamma[i]);
        const double tau_v = fmax(0.0, tau[i]);
        const double k_v = fmax(ANALYTICS_EPS, k[i]);

        if (ask <= bid || gamma_v <= ANALYTICS_EPS || tau_v <= ANALYTICS_EPS) {
            out_sigma_b[i] = 0.0;
            continue;
        }

        const double target_spread = kernel_logit(ask) - kernel_logit(bid);
        const double two_non_linear = 2.0 * (log1p(gamma_v / k_v) / k_v);
        const double gamma_tau = fmax(ANALYTICS_DIV_EPS, gamma_v * tau_v);

        out_sigma_b[i] = sqrt(fmax(0.0, target_spread - two_non_linear) / gamma_tau);
    }
}

#if PM_SIMD_HAS_NEON
void pm_internal_implied_belief_volatility_batch_neon(
    const double *bid_p,
    const double *ask_p,
    const double *q_t,
    const double *gamma,
    const double *tau,
    const double *k,
    double *out_sigma_b,
    size_t n
) {
    (void)q_t;

    const float64x2_t v_zero = vdupq_n_f64(0.0);
    const float64x2_t v_two = vdupq_n_f64(2.0);
    const float64x2_t v_eps = vdupq_n_f64(ANALYTICS_EPS);
    const float64x2_t v_one_minus_eps = vdupq_n_f64(ANALYTICS_ONE_MINUS_EPS);
    const float64x2_t v_div_eps = vdupq_n_f64(ANALYTICS_DIV_EPS);

    size_t i = 0u;
    for (; (i + 1u) < n; i += 2u) {
        const float64x2_t bid =
            vmaxq_f64(v_eps, vminq_f64(v_one_minus_eps, vld1q_f64(bid_p + i)));
        const float64x2_t ask =
            vmaxq_f64(v_eps, vminq_f64(v_one_minus_eps, vld1q_f64(ask_p + i)));
        const float64x2_t gamma_v = vmaxq_f64(v_zero, vld1q_f64(gamma + i));
        const float64x2_t tau_v = vmaxq_f64(v_zero, vld1q_f64(tau + i));
        const float64x2_t k_v = vmaxq_f64(v_eps, vld1q_f64(k + i));

        const float64x2_t target_spread =
            vsubq_f64(pm_neon_logit_pd(ask), pm_neon_logit_pd(bid));
        const float64x2_t non_linear =
            vdivq_f64(pm_neon_log1p_pd(vdivq_f64(gamma_v, k_v)), k_v);
        const float64x2_t two_non_linear = vmulq_f64(v_two, non_linear);
        const float64x2_t gamma_tau = vmaxq_f64(v_div_eps, vmulq_f64(gamma_v, tau_v));

        const float64x2_t numer = vmaxq_f64(v_zero, vsubq_f64(target_spread, two_non_linear));
        const float64x2_t sigma = vsqrtq_f64(vdivq_f64(numer, gamma_tau));

        const uint64x2_t valid = vandq_u64(
            vcgtq_f64(ask, bid),
            vandq_u64(vcgtq_f64(gamma_v, v_eps), vcgtq_f64(tau_v, v_eps))
        );
        vst1q_f64(out_sigma_b + i, vbslq_f64(valid, sigma, v_zero));
    }

    pm_internal_implied_belief_volatility_batch_portable(
        bid_p + i, ask_p + i, NULL, gamma + i, tau + i, k + i, out_sigma_b + i, n - i
    );
}
#endif

#if PM_ANALYTICS_HAS_AVX512_DISPATCH
PM_ANALYTICS_TARGET_AVX512
void pm_internal_implied_belief_volatility_batch_avx512(
    const double *bid_p,
    const double *ask_p,
    const double *q_t,
    const double *gamma,
    const double *tau,
    const double *k,
    double *out_sigma_b,
    size_t n
) {
    if (bid_p == NULL || ask_p == NULL || gamma == NULL || tau == NULL || k == NULL || out_sigma_b == NULL || n == 0u) {
        return;
    }

    (void)q_t;

    const __m512d v_zero = _mm512_set1_pd(0.0);
    const __m512d v_two = _mm512_set1_pd(2.0);
    const __m512d v_eps = _mm512_set1_pd(ANALYTICS_EPS);
    const __m512d v_one_minus_eps = _mm512_set1_pd(ANALYTICS_ONE_MINUS_EPS);
    const __m512d v_div_eps = _mm512_set1_pd(ANALYTICS_DIV_EPS);

    size_t i = 0u;
    for (; (i + 7u) < n; i += 8u) {
        const __m512d bid = _mm512_max_pd(
            v_eps, _mm512_min_pd(v_one_minus_eps, _mm512_loadu_pd(bid_p + i)));
        const __m512d ask = _mm512_max_pd(
            v_eps, _mm512_min_pd(v_one_minus_eps, _mm512_loadu_pd(ask_p + i)));
        const __m512d gamma_v = _mm512_max_pd(v_zero, _mm512_loadu_pd(gamma + i));
        const __m512d tau_v = _mm512_max_pd(v_zero, _mm512_loadu_pd(tau + i));
        const __m512d k_v = _mm512_max_pd(v_eps, _mm512_loadu_pd(k + i));

        const __m512d target_spread =
            _mm512_sub_pd(pm_avx512_logit_pd(ask), pm_avx512_logit_pd(bid));
        const __m512d non_linear =
            _mm512_div_pd(pm_avx512_log1p_pd(_mm512_div_pd(gamma_v, k_v)), k_v);
        const __m512d two_non_linear = _mm512_mul_pd(v_two, non_linear);
        const __m512d gamma_tau = _mm512_max_pd(v_div_eps, _mm512_mul_pd(gamma_v, tau_v));

        const __m512d numer =
            _mm512_max_pd(v_zero, _mm512_sub_pd(target_spread, two_non_linear));
        const __m512d sigma = _mm512_sqrt_pd(_mm512_div_pd(numer, gamma_tau));

        const __mmask8 valid = _mm512_cmp_pd_mask(ask, bid, _CMP_GT_OQ) &
                               _mm512_cmp_pd_mask(gamma_v, v_eps, _CMP_GT_OQ) &
                               _mm512_cmp_pd_mask(tau_v, v_eps, _CMP_GT_OQ);
        _mm512_storeu_pd(out_sigma_b + i, _mm512_maskz_mov_pd(valid, sigma));
    }

    pm_internal_implied_belief_volatility_batch_portable(
        bid_p + i,
        ask_p + i,
        q_t != NULL ? q_t + i : NULL,
        gamma + i,
        tau + i,
        k + i,
        out_sigma_b + i,
        n - i
    );
}
#endif

void implied_belief_volatility_batch(
    const double *bid_p,
    const double *ask_p,
    const double *q_t,
    const double *gamma,
    const double *tau,
    const double *k,
    double *out_sigma_b,
    size_t n
) {
    if (bid_p == NULL || ask_p == NULL || gamma == NULL || tau == NULL || k == NULL || out_sigma_b == NULL || n == 0u) {
        return;
    }

#if PM_SIMD_HAS_NEON
    pm_internal_implied_belief_volatility_batch_neon(bid_p, ask_p, q_t, gamma, tau, k, out_sigma_b, n);
    return;
#else
#if PM_ANALYTICS_HAS_AVX512_DISPATCH
    if (analytics_runtime_has_avx512()) {
        pm_internal_implied_belief_volatility_batch_avx512(
            bid_p, ask_p, q_t, gamma, tau, k, out_sigma_b, n
        );
        return;
    }
#endif
    pm_internal_implied_belief_volatility_batch_portable(
        bid_p, ask_p, q_t, gamma, tau, k, out_sigma_b, n
    );
#endif
}

void pm_internal_simulate_shock_logit_batch_portable(
    const double *x_t,
    const double *q_t,
    const double *sigma_b,
    const double *gamma,
    const double *tau,
    const double *k,
    const double *shock_p,
    double *out_r_x,
    double *out_bid_p,
    double *out_ask_p,
    greek_out_t *out_greeks,
    double *out_pnl_shift,
    size_t n
) {
    if (x_t == NULL || q_t == NULL || sigma_b == NULL || gamma == NULL || tau == NULL || k == NULL || shock_p == NULL ||
        out_r_x == NULL || out_bid_p == NULL || out_ask_p == NULL || out_greeks == NULL || out_pnl_shift == NULL || n == 0u) {
        return;
    }

    ANALYTICS_UNROLL_4
    for (size_t i = 0u; i < n; ++i) {
        const double base_p = kernel_sigmoid(x_t[i]);
        const double shocked_p = analytics_clamp(base_p + shock_p[i], ANALYTICS_EPS, ANALYTICS_ONE_MINUS_EPS);
        const double x_shocked = kernel_logit(shocked_p);

        const double gamma_v = fmax(0.0, gamma[i]);
        const double tau_v = fmax(0.0, tau[i]);
        const double k_v = fmax(ANALYTICS_EPS, k[i]);

        const double sigma2 = sigma_b[i] * sigma_b[i];
        const double risk_term = gamma_v * sigma2 * tau_v;
        const double r_x = x_shocked - (q_t[i] * risk_term);
        const double half_spread = (0.5 * risk_term) + (log1p(gamma_v / k_v) / k_v);

        out_r_x[i] = r_x;
        out_bid_p[i] = kernel_sigmoid(r_x - half_spread);
        out_ask_p[i] = kernel_sigmoid(r_x + half_spread);

        /* sigmoid(x_shocked) == shocked_p by construction, so the greeks come
           straight from the shocked probability without a logit round-trip. */
        const double delta = shocked_p * (1.0 - shocked_p);
        out_greeks[i].delta_x = delta;
        out_greeks[i].gamma_x = delta * (1.0 - (2.0 * shocked_p));

        out_pnl_shift[i] = q_t[i] * (shocked_p - base_p);
    }
}

#if PM_SIMD_HAS_NEON
void pm_internal_simulate_shock_logit_batch_neon(
    const double *x_t,
    const double *q_t,
    const double *sigma_b,
    const double *gamma,
    const double *tau,
    const double *k,
    const double *shock_p,
    double *out_r_x,
    double *out_bid_p,
    double *out_ask_p,
    greek_out_t *out_greeks,
    double *out_pnl_shift,
    size_t n
) {
    const float64x2_t v_zero = vdupq_n_f64(0.0);
    const float64x2_t v_half = vdupq_n_f64(0.5);
    const float64x2_t v_one = vdupq_n_f64(1.0);
    const float64x2_t v_two = vdupq_n_f64(2.0);
    const float64x2_t v_eps = vdupq_n_f64(ANALYTICS_EPS);
    const float64x2_t v_one_minus_eps = vdupq_n_f64(ANALYTICS_ONE_MINUS_EPS);

    size_t i = 0u;
    for (; (i + 1u) < n; i += 2u) {
        const float64x2_t q = vld1q_f64(q_t + i);
        const float64x2_t base_p = pm_neon_sigmoid_pd(vld1q_f64(x_t + i));
        const float64x2_t shocked_p = vmaxq_f64(
            v_eps,
            vminq_f64(v_one_minus_eps, vaddq_f64(base_p, vld1q_f64(shock_p + i)))
        );
        const float64x2_t x_shocked = pm_neon_logit_pd(shocked_p);

        const float64x2_t gamma_v = vmaxq_f64(v_zero, vld1q_f64(gamma + i));
        const float64x2_t tau_v = vmaxq_f64(v_zero, vld1q_f64(tau + i));
        const float64x2_t k_v = vmaxq_f64(v_eps, vld1q_f64(k + i));

        const float64x2_t sigma = vld1q_f64(sigma_b + i);
        const float64x2_t risk_term =
            vmulq_f64(gamma_v, vmulq_f64(vmulq_f64(sigma, sigma), tau_v));
        const float64x2_t r_x = vfmsq_f64(x_shocked, q, risk_term);
        const float64x2_t rk = vdivq_f64(v_one, k_v);
        const float64x2_t non_linear =
            vmulq_f64(pm_neon_log1p_pd(vmulq_f64(gamma_v, rk)), rk);
        const float64x2_t half_spread = vfmaq_f64(non_linear, v_half, risk_term);

        vst1q_f64(out_r_x + i, r_x);
        vst1q_f64(out_bid_p + i, pm_neon_sigmoid_pd(vsubq_f64(r_x, half_spread)));
        vst1q_f64(out_ask_p + i, pm_neon_sigmoid_pd(vaddq_f64(r_x, half_spread)));

        const float64x2_t delta = vmulq_f64(shocked_p, vsubq_f64(v_one, shocked_p));
        const float64x2_t gamma_x = vmulq_f64(delta, vfmsq_f64(v_one, v_two, shocked_p));
        vst1q_f64(&out_greeks[i].delta_x, vzip1q_f64(delta, gamma_x));
        vst1q_f64(&out_greeks[i + 1u].delta_x, vzip2q_f64(delta, gamma_x));

        vst1q_f64(out_pnl_shift + i, vmulq_f64(q, vsubq_f64(shocked_p, base_p)));
    }

    pm_internal_simulate_shock_logit_batch_portable(
        x_t + i, q_t + i, sigma_b + i, gamma + i, tau + i, k + i, shock_p + i,
        out_r_x + i, out_bid_p + i, out_ask_p + i, out_greeks + i, out_pnl_shift + i, n - i
    );
}
#endif

#if PM_ANALYTICS_HAS_AVX512_DISPATCH
PM_ANALYTICS_TARGET_AVX512
void pm_internal_simulate_shock_logit_batch_avx512(
    const double *x_t,
    const double *q_t,
    const double *sigma_b,
    const double *gamma,
    const double *tau,
    const double *k,
    const double *shock_p,
    double *out_r_x,
    double *out_bid_p,
    double *out_ask_p,
    greek_out_t *out_greeks,
    double *out_pnl_shift,
    size_t n
) {
    if (x_t == NULL || q_t == NULL || sigma_b == NULL || gamma == NULL || tau == NULL || k == NULL || shock_p == NULL ||
        out_r_x == NULL || out_bid_p == NULL || out_ask_p == NULL || out_greeks == NULL || out_pnl_shift == NULL || n == 0u) {
        return;
    }

    const __m512d v_zero = _mm512_set1_pd(0.0);
    const __m512d v_half = _mm512_set1_pd(0.5);
    const __m512d v_one = _mm512_set1_pd(1.0);
    const __m512d v_two = _mm512_set1_pd(2.0);
    const __m512d v_eps = _mm512_set1_pd(ANALYTICS_EPS);
    const __m512d v_one_minus_eps = _mm512_set1_pd(ANALYTICS_ONE_MINUS_EPS);

    size_t i = 0u;
    for (; (i + 7u) < n; i += 8u) {
        const __m512d q = _mm512_loadu_pd(q_t + i);
        const __m512d base_p = pm_avx512_sigmoid_pd(_mm512_loadu_pd(x_t + i));
        const __m512d shocked_p = _mm512_max_pd(
            v_eps,
            _mm512_min_pd(v_one_minus_eps,
                          _mm512_add_pd(base_p, _mm512_loadu_pd(shock_p + i)))
        );
        const __m512d x_shocked = pm_avx512_logit_pd(shocked_p);

        const __m512d gamma_v = _mm512_max_pd(v_zero, _mm512_loadu_pd(gamma + i));
        const __m512d tau_v = _mm512_max_pd(v_zero, _mm512_loadu_pd(tau + i));
        const __m512d k_v = _mm512_max_pd(v_eps, _mm512_loadu_pd(k + i));

        const __m512d sigma = _mm512_loadu_pd(sigma_b + i);
        const __m512d risk_term =
            _mm512_mul_pd(gamma_v, _mm512_mul_pd(_mm512_mul_pd(sigma, sigma), tau_v));
        const __m512d r_x = _mm512_fnmadd_pd(q, risk_term, x_shocked);
        const __m512d rk = _mm512_div_pd(v_one, k_v);
        const __m512d non_linear =
            _mm512_mul_pd(pm_avx512_log1p_pd(_mm512_mul_pd(gamma_v, rk)), rk);
        const __m512d half_spread = _mm512_fmadd_pd(v_half, risk_term, non_linear);

        _mm512_storeu_pd(out_r_x + i, r_x);
        _mm512_storeu_pd(out_bid_p + i, pm_avx512_sigmoid_pd(_mm512_sub_pd(r_x, half_spread)));
        _mm512_storeu_pd(out_ask_p + i, pm_avx512_sigmoid_pd(_mm512_add_pd(r_x, half_spread)));

        const __m512d delta = _mm512_mul_pd(shocked_p, _mm512_sub_pd(v_one, shocked_p));
        const __m512d gamma_x = _mm512_mul_pd(delta, _mm512_fnmadd_pd(v_two, shocked_p, v_one));

        double delta_buf[8];
        double gamma_buf[8];
        _mm512_storeu_pd(delta_buf, delta);
        _mm512_storeu_pd(gamma_buf, gamma_x);
        for (size_t lane = 0u; lane < 8u; ++lane) {
            out_greeks[i + lane].delta_x = delta_buf[lane];
            out_greeks[i + lane].gamma_x = gamma_buf[lane];
        }

        _mm512_storeu_pd(out_pnl_shift + i, _mm512_mul_pd(q, _mm512_sub_pd(shocked_p, base_p)));
    }

    pm_internal_simulate_shock_logit_batch_portable(
        x_t + i, q_t + i, sigma_b + i, gamma + i, tau + i, k + i, shock_p + i,
        out_r_x + i, out_bid_p + i, out_ask_p + i, out_greeks + i, out_pnl_shift + i, n - i
    );
}
#endif

void simulate_shock_logit_batch(
    const double *x_t,
    const double *q_t,
    const double *sigma_b,
    const double *gamma,
    const double *tau,
    const double *k,
    const double *shock_p,
    double *out_r_x,
    double *out_bid_p,
    double *out_ask_p,
    greek_out_t *out_greeks,
    double *out_pnl_shift,
    size_t n
) {
    if (x_t == NULL || q_t == NULL || sigma_b == NULL || gamma == NULL || tau == NULL || k == NULL || shock_p == NULL ||
        out_r_x == NULL || out_bid_p == NULL || out_ask_p == NULL || out_greeks == NULL || out_pnl_shift == NULL || n == 0u) {
        return;
    }

#if PM_SIMD_HAS_NEON
    pm_internal_simulate_shock_logit_batch_neon(
        x_t, q_t, sigma_b, gamma, tau, k, shock_p,
        out_r_x, out_bid_p, out_ask_p, out_greeks, out_pnl_shift, n
    );
    return;
#else
#if PM_ANALYTICS_HAS_AVX512_DISPATCH
    if (analytics_runtime_has_avx512()) {
        pm_internal_simulate_shock_logit_batch_avx512(
            x_t, q_t, sigma_b, gamma, tau, k, shock_p,
            out_r_x, out_bid_p, out_ask_p, out_greeks, out_pnl_shift, n
        );
        return;
    }
#endif
    pm_internal_simulate_shock_logit_batch_portable(
        x_t, q_t, sigma_b, gamma, tau, k, shock_p,
        out_r_x, out_bid_p, out_ask_p, out_greeks, out_pnl_shift, n
    );
#endif
}

void pm_internal_adaptive_kelly_clip_batch_portable(
    const double *belief_p,
    const double *market_p,
    const double *q_t,
    const double *gamma,
    const double *risk_limit,
    const double *max_clip,
    double *out_maker_clip,
    double *out_taker_clip,
    size_t n
) {
    if (belief_p == NULL || market_p == NULL || q_t == NULL || gamma == NULL || risk_limit == NULL || max_clip == NULL ||
        out_maker_clip == NULL || out_taker_clip == NULL || n == 0u) {
        return;
    }

    ANALYTICS_UNROLL_4
    for (size_t i = 0u; i < n; ++i) {
        const double belief = analytics_clamp(belief_p[i], ANALYTICS_EPS, ANALYTICS_ONE_MINUS_EPS);
        const double market = analytics_clamp(market_p[i], ANALYTICS_EPS, ANALYTICS_ONE_MINUS_EPS);
        const double edge = belief - market;
        const double variance = fmax(ANALYTICS_EPS, market * (1.0 - market));
        const double kelly_frac = edge / variance;

        const double gamma_v = fmax(0.0, gamma[i]);
        const double inventory_scale = 1.0 / (1.0 + (gamma_v * fabs(q_t[i])));

        const double risk = fmax(ANALYTICS_EPS, risk_limit[i]);
        const double clip_cap = fmax(ANALYTICS_EPS, max_clip[i]);

        double taker = kelly_frac * risk * inventory_scale;
        taker = analytics_clamp(taker, -clip_cap, clip_cap);

        const double long_limit = risk - q_t[i];
        const double short_limit = -risk - q_t[i];

        taker = analytics_clamp(taker, short_limit, long_limit);
        const double maker = analytics_clamp(0.5 * taker, short_limit, long_limit);

        out_maker_clip[i] = maker;
        out_taker_clip[i] = taker;
    }
}

#if PM_ANALYTICS_HAS_AVX512_DISPATCH
PM_ANALYTICS_TARGET_AVX512
void pm_internal_adaptive_kelly_clip_batch_avx512(
    const double *belief_p,
    const double *market_p,
    const double *q_t,
    const double *gamma,
    const double *risk_limit,
    const double *max_clip,
    double *out_maker_clip,
    double *out_taker_clip,
    size_t n
) {
    if (belief_p == NULL || market_p == NULL || q_t == NULL || gamma == NULL || risk_limit == NULL || max_clip == NULL ||
        out_maker_clip == NULL || out_taker_clip == NULL || n == 0u) {
        return;
    }

    const __m512d v_zero = _mm512_set1_pd(0.0);
    const __m512d v_one = _mm512_set1_pd(1.0);
    const __m512d v_half = _mm512_set1_pd(0.5);
    const __m512d v_eps = _mm512_set1_pd(ANALYTICS_EPS);
    const __m512d v_one_minus_eps = _mm512_set1_pd(ANALYTICS_ONE_MINUS_EPS);
    const __m512d v_abs_mask = _mm512_castsi512_pd(_mm512_set1_epi64(0x7fffffffffffffffULL));

    size_t i = 0u;
    for (; (i + 7u) < n; i += 8u) {
        const __m512d belief_raw = _mm512_loadu_pd(belief_p + i);
        const __m512d market_raw = _mm512_loadu_pd(market_p + i);
        const __m512d q = _mm512_loadu_pd(q_t + i);
        const __m512d gamma_raw = _mm512_loadu_pd(gamma + i);
        const __m512d risk_raw = _mm512_loadu_pd(risk_limit + i);
        const __m512d clip_raw = _mm512_loadu_pd(max_clip + i);

        const __m512d belief = _mm512_max_pd(v_eps, _mm512_min_pd(v_one_minus_eps, belief_raw));
        const __m512d market = _mm512_max_pd(v_eps, _mm512_min_pd(v_one_minus_eps, market_raw));

        const __m512d edge = _mm512_sub_pd(belief, market);
        const __m512d variance = _mm512_max_pd(v_eps, _mm512_mul_pd(market, _mm512_sub_pd(v_one, market)));
        const __m512d kelly_frac = _mm512_div_pd(edge, variance);

        const __m512d gamma_v = _mm512_max_pd(v_zero, gamma_raw);
        const __m512d abs_q = _mm512_and_pd(q, v_abs_mask);
        const __m512d inventory_scale = _mm512_div_pd(v_one, _mm512_add_pd(v_one, _mm512_mul_pd(gamma_v, abs_q)));

        const __m512d risk = _mm512_max_pd(v_eps, risk_raw);
        const __m512d clip_cap = _mm512_max_pd(v_eps, clip_raw);
        const __m512d neg_clip_cap = _mm512_sub_pd(v_zero, clip_cap);

        __m512d taker = _mm512_mul_pd(kelly_frac, _mm512_mul_pd(risk, inventory_scale));
        taker = _mm512_max_pd(neg_clip_cap, _mm512_min_pd(clip_cap, taker));

        const __m512d long_limit = _mm512_sub_pd(risk, q);
        const __m512d short_limit = _mm512_sub_pd(_mm512_sub_pd(v_zero, risk), q);
        taker = _mm512_max_pd(short_limit, _mm512_min_pd(long_limit, taker));

        __m512d maker = _mm512_mul_pd(v_half, taker);
        maker = _mm512_max_pd(short_limit, _mm512_min_pd(long_limit, maker));

        _mm512_storeu_pd(out_maker_clip + i, maker);
        _mm512_storeu_pd(out_taker_clip + i, taker);
    }

    pm_internal_adaptive_kelly_clip_batch_portable(
        belief_p + i,
        market_p + i,
        q_t + i,
        gamma + i,
        risk_limit + i,
        max_clip + i,
        out_maker_clip + i,
        out_taker_clip + i,
        n - i
    );
}
#endif

void adaptive_kelly_clip_batch(
    const double *belief_p,
    const double *market_p,
    const double *q_t,
    const double *gamma,
    const double *risk_limit,
    const double *max_clip,
    double *out_maker_clip,
    double *out_taker_clip,
    size_t n
) {
    if (analytics_runtime_has_avx512()) {
#if PM_ANALYTICS_HAS_AVX512_DISPATCH
        pm_internal_adaptive_kelly_clip_batch_avx512(
            belief_p,
            market_p,
            q_t,
            gamma,
            risk_limit,
            max_clip,
            out_maker_clip,
            out_taker_clip,
            n
        );
        return;
#endif
    }

    pm_internal_adaptive_kelly_clip_batch_portable(
        belief_p,
        market_p,
        q_t,
        gamma,
        risk_limit,
        max_clip,
        out_maker_clip,
        out_taker_clip,
        n
    );
}

void pm_internal_order_book_microstructure_batch_portable(
    const double *bid_p,
    const double *ask_p,
    const double *bid_vol,
    const double *ask_vol,
    double *out_obi,
    double *out_vwm_p,
    double *out_vwm_x,
    double *out_pressure,
    size_t n
) {
    if (bid_p == NULL || ask_p == NULL || bid_vol == NULL || ask_vol == NULL || out_obi == NULL || out_vwm_p == NULL ||
        out_vwm_x == NULL || out_pressure == NULL || n == 0u) {
        return;
    }

    ANALYTICS_UNROLL_4
    for (size_t i = 0u; i < n; ++i) {
        const double bid = analytics_clamp(bid_p[i], ANALYTICS_EPS, ANALYTICS_ONE_MINUS_EPS);
        const double ask = analytics_clamp(ask_p[i], ANALYTICS_EPS, ANALYTICS_ONE_MINUS_EPS);
        const double bv = fmax(0.0, bid_vol[i]);
        const double av = fmax(0.0, ask_vol[i]);

        const double vol_sum = fmax(ANALYTICS_EPS, bv + av);
        const double obi = (bv - av) / vol_sum;

        const double vwm = analytics_clamp(((ask * bv) + (bid * av)) / vol_sum, ANALYTICS_EPS, ANALYTICS_ONE_MINUS_EPS);
        const double mid = 0.5 * (bid + ask);
        const double spread = fmax(ANALYTICS_EPS, ask - bid);
        const double pressure = obi + ((vwm - mid) / spread);

        out_obi[i] = obi;
        out_vwm_p[i] = vwm;
        out_vwm_x[i] = kernel_logit(vwm);
        out_pressure[i] = pressure;
    }
}

#if PM_SIMD_HAS_NEON
void pm_internal_order_book_microstructure_batch_neon(
    const double *bid_p,
    const double *ask_p,
    const double *bid_vol,
    const double *ask_vol,
    double *out_obi,
    double *out_vwm_p,
    double *out_vwm_x,
    double *out_pressure,
    size_t n
) {
    const float64x2_t v_zero = vdupq_n_f64(0.0);
    const float64x2_t v_half = vdupq_n_f64(0.5);
    const float64x2_t v_eps = vdupq_n_f64(ANALYTICS_EPS);
    const float64x2_t v_one_minus_eps = vdupq_n_f64(ANALYTICS_ONE_MINUS_EPS);

    size_t i = 0u;
    for (; (i + 1u) < n; i += 2u) {
        const float64x2_t bid =
            vmaxq_f64(v_eps, vminq_f64(v_one_minus_eps, vld1q_f64(bid_p + i)));
        const float64x2_t ask =
            vmaxq_f64(v_eps, vminq_f64(v_one_minus_eps, vld1q_f64(ask_p + i)));
        const float64x2_t bv = vmaxq_f64(v_zero, vld1q_f64(bid_vol + i));
        const float64x2_t av = vmaxq_f64(v_zero, vld1q_f64(ask_vol + i));

        const float64x2_t vol_sum = vmaxq_f64(v_eps, vaddq_f64(bv, av));
        const float64x2_t obi = vdivq_f64(vsubq_f64(bv, av), vol_sum);

        const float64x2_t vwm_num = vfmaq_f64(vmulq_f64(bid, av), ask, bv);
        const float64x2_t vwm = vmaxq_f64(
            v_eps, vminq_f64(v_one_minus_eps, vdivq_f64(vwm_num, vol_sum)));

        const float64x2_t mid = vmulq_f64(v_half, vaddq_f64(bid, ask));
        const float64x2_t spread = vmaxq_f64(v_eps, vsubq_f64(ask, bid));
        const float64x2_t pressure =
            vaddq_f64(obi, vdivq_f64(vsubq_f64(vwm, mid), spread));

        vst1q_f64(out_obi + i, obi);
        vst1q_f64(out_vwm_p + i, vwm);
        vst1q_f64(out_vwm_x + i, pm_neon_logit_pd(vwm));
        vst1q_f64(out_pressure + i, pressure);
    }

    pm_internal_order_book_microstructure_batch_portable(
        bid_p + i, ask_p + i, bid_vol + i, ask_vol + i,
        out_obi + i, out_vwm_p + i, out_vwm_x + i, out_pressure + i, n - i
    );
}
#endif

#if PM_ANALYTICS_HAS_AVX512_DISPATCH
PM_ANALYTICS_TARGET_AVX512
void pm_internal_order_book_microstructure_batch_avx512(
    const double *bid_p,
    const double *ask_p,
    const double *bid_vol,
    const double *ask_vol,
    double *out_obi,
    double *out_vwm_p,
    double *out_vwm_x,
    double *out_pressure,
    size_t n
) {
    if (bid_p == NULL || ask_p == NULL || bid_vol == NULL || ask_vol == NULL || out_obi == NULL || out_vwm_p == NULL ||
        out_vwm_x == NULL || out_pressure == NULL || n == 0u) {
        return;
    }

    const __m512d v_zero = _mm512_set1_pd(0.0);
    const __m512d v_half = _mm512_set1_pd(0.5);
    const __m512d v_eps = _mm512_set1_pd(ANALYTICS_EPS);
    const __m512d v_one_minus_eps = _mm512_set1_pd(ANALYTICS_ONE_MINUS_EPS);

    size_t i = 0u;
    for (; (i + 7u) < n; i += 8u) {
        const __m512d bid = _mm512_max_pd(
            v_eps, _mm512_min_pd(v_one_minus_eps, _mm512_loadu_pd(bid_p + i)));
        const __m512d ask = _mm512_max_pd(
            v_eps, _mm512_min_pd(v_one_minus_eps, _mm512_loadu_pd(ask_p + i)));
        const __m512d bv = _mm512_max_pd(v_zero, _mm512_loadu_pd(bid_vol + i));
        const __m512d av = _mm512_max_pd(v_zero, _mm512_loadu_pd(ask_vol + i));

        const __m512d vol_sum = _mm512_max_pd(v_eps, _mm512_add_pd(bv, av));
        const __m512d obi = _mm512_div_pd(_mm512_sub_pd(bv, av), vol_sum);

        const __m512d vwm_num = _mm512_fmadd_pd(ask, bv, _mm512_mul_pd(bid, av));
        const __m512d vwm = _mm512_max_pd(
            v_eps, _mm512_min_pd(v_one_minus_eps, _mm512_div_pd(vwm_num, vol_sum)));

        const __m512d mid = _mm512_mul_pd(v_half, _mm512_add_pd(bid, ask));
        const __m512d spread = _mm512_max_pd(v_eps, _mm512_sub_pd(ask, bid));
        const __m512d pressure =
            _mm512_add_pd(obi, _mm512_div_pd(_mm512_sub_pd(vwm, mid), spread));

        _mm512_storeu_pd(out_obi + i, obi);
        _mm512_storeu_pd(out_vwm_p + i, vwm);
        _mm512_storeu_pd(out_vwm_x + i, pm_avx512_logit_pd(vwm));
        _mm512_storeu_pd(out_pressure + i, pressure);
    }

    pm_internal_order_book_microstructure_batch_portable(
        bid_p + i,
        ask_p + i,
        bid_vol + i,
        ask_vol + i,
        out_obi + i,
        out_vwm_p + i,
        out_vwm_x + i,
        out_pressure + i,
        n - i
    );
}
#endif

void order_book_microstructure_batch(
    const double *bid_p,
    const double *ask_p,
    const double *bid_vol,
    const double *ask_vol,
    double *out_obi,
    double *out_vwm_p,
    double *out_vwm_x,
    double *out_pressure,
    size_t n
) {
    if (bid_p == NULL || ask_p == NULL || bid_vol == NULL || ask_vol == NULL || out_obi == NULL || out_vwm_p == NULL ||
        out_vwm_x == NULL || out_pressure == NULL || n == 0u) {
        return;
    }

#if PM_SIMD_HAS_NEON
    pm_internal_order_book_microstructure_batch_neon(
        bid_p, ask_p, bid_vol, ask_vol, out_obi, out_vwm_p, out_vwm_x, out_pressure, n
    );
    return;
#else
#if PM_ANALYTICS_HAS_AVX512_DISPATCH
    if (analytics_runtime_has_avx512()) {
        pm_internal_order_book_microstructure_batch_avx512(
            bid_p, ask_p, bid_vol, ask_vol, out_obi, out_vwm_p, out_vwm_x, out_pressure, n
        );
        return;
    }
#endif
    pm_internal_order_book_microstructure_batch_portable(
        bid_p, ask_p, bid_vol, ask_vol, out_obi, out_vwm_p, out_vwm_x, out_pressure, n
    );
#endif
}

void pm_internal_aggregate_portfolio_greeks_portable(
    const double *positions,
    const double *delta_x,
    const double *gamma_x,
    const double *weights,
    const double *corr_matrix,
    size_t n,
    double *out_net_delta,
    double *out_net_gamma
) {
    if (positions == NULL || delta_x == NULL || gamma_x == NULL || out_net_delta == NULL || out_net_gamma == NULL) {
        return;
    }

    if (n == 0u) {
        *out_net_delta = 0.0;
        *out_net_gamma = 0.0;
        return;
    }

    double net_delta = 0.0;
    double net_gamma = 0.0;

    if (corr_matrix == NULL) {
        ANALYTICS_UNROLL_4
        for (size_t i = 0u; i < n; ++i) {
            const double w = (weights != NULL) ? weights[i] : 1.0;
            net_delta += positions[i] * delta_x[i] * w;
            net_gamma += positions[i] * gamma_x[i] * w;
        }

        *out_net_delta = net_delta;
        *out_net_gamma = net_gamma;
        return;
    }

    for (size_t i = 0u; i < n; ++i) {
        const double wi = (weights != NULL) ? weights[i] : 1.0;
        const double exp_delta_i = positions[i] * delta_x[i] * wi;
        const double exp_gamma_i = positions[i] * gamma_x[i] * wi;

        const double *corr_row = corr_matrix + (i * n);
        double row_delta = 0.0;
        double row_gamma = 0.0;

        ANALYTICS_UNROLL_4
        for (size_t j = 0u; j < n; ++j) {
            const double wj = (weights != NULL) ? weights[j] : 1.0;
            const double exp_delta_j = positions[j] * delta_x[j] * wj;
            const double exp_gamma_j = positions[j] * gamma_x[j] * wj;
            const double corr = corr_row[j];

            row_delta += corr * exp_delta_j;
            row_gamma += corr * exp_gamma_j;
        }

        net_delta += exp_delta_i * row_delta;
        net_gamma += exp_gamma_i * row_gamma;
    }

    *out_net_delta = net_delta;
    *out_net_gamma = net_gamma;
}

#if PM_ANALYTICS_HAS_AVX512_DISPATCH
PM_ANALYTICS_TARGET_AVX512
void pm_internal_aggregate_portfolio_greeks_avx512(
    const double *positions,
    const double *delta_x,
    const double *gamma_x,
    const double *weights,
    const double *corr_matrix,
    size_t n,
    double *out_net_delta,
    double *out_net_gamma
) {
    if (positions == NULL || delta_x == NULL || gamma_x == NULL || out_net_delta == NULL || out_net_gamma == NULL) {
        return;
    }

    if (n == 0u) {
        *out_net_delta = 0.0;
        *out_net_gamma = 0.0;
        return;
    }

    double net_delta = 0.0;
    double net_gamma = 0.0;

    if (corr_matrix == NULL) {
        size_t i = 0u;
        __m512d acc_delta = _mm512_setzero_pd();
        __m512d acc_gamma = _mm512_setzero_pd();

        for (; (i + 7u) < n; i += 8u) {
            const __m512d pos = _mm512_loadu_pd(positions + i);
            const __m512d del = _mm512_loadu_pd(delta_x + i);
            const __m512d gam = _mm512_loadu_pd(gamma_x + i);
            const __m512d w = (weights != NULL) ? _mm512_loadu_pd(weights + i) : _mm512_set1_pd(1.0);

            acc_delta = _mm512_fmadd_pd(_mm512_mul_pd(pos, del), w, acc_delta);
            acc_gamma = _mm512_fmadd_pd(_mm512_mul_pd(pos, gam), w, acc_gamma);
        }

        net_delta += _mm512_reduce_add_pd(acc_delta);
        net_gamma += _mm512_reduce_add_pd(acc_gamma);

        pm_internal_aggregate_portfolio_greeks_portable(
            positions + i,
            delta_x + i,
            gamma_x + i,
            weights != NULL ? weights + i : NULL,
            NULL,
            n - i,
            out_net_delta,
            out_net_gamma
        );

        net_delta += *out_net_delta;
        net_gamma += *out_net_gamma;
        *out_net_delta = net_delta;
        *out_net_gamma = net_gamma;
        return;
    }

    for (size_t i = 0u; i < n; ++i) {
        const double wi = (weights != NULL) ? weights[i] : 1.0;
        const double exp_delta_i = positions[i] * delta_x[i] * wi;
        const double exp_gamma_i = positions[i] * gamma_x[i] * wi;

        const double *corr_row = corr_matrix + (i * n);
        double row_delta = 0.0;
        double row_gamma = 0.0;

        size_t j = 0u;
        __m512d acc_delta = _mm512_setzero_pd();
        __m512d acc_gamma = _mm512_setzero_pd();

        for (; (j + 7u) < n; j += 8u) {
            const __m512d corr = _mm512_loadu_pd(corr_row + j);
            const __m512d pos = _mm512_loadu_pd(positions + j);
            const __m512d del = _mm512_loadu_pd(delta_x + j);
            const __m512d gam = _mm512_loadu_pd(gamma_x + j);
            const __m512d wj = (weights != NULL) ? _mm512_loadu_pd(weights + j) : _mm512_set1_pd(1.0);

            const __m512d exp_delta_j = _mm512_mul_pd(_mm512_mul_pd(pos, del), wj);
            const __m512d exp_gamma_j = _mm512_mul_pd(_mm512_mul_pd(pos, gam), wj);

            acc_delta = _mm512_fmadd_pd(corr, exp_delta_j, acc_delta);
            acc_gamma = _mm512_fmadd_pd(corr, exp_gamma_j, acc_gamma);
        }

        row_delta += _mm512_reduce_add_pd(acc_delta);
        row_gamma += _mm512_reduce_add_pd(acc_gamma);

        for (; j < n; ++j) {
            const double wj = (weights != NULL) ? weights[j] : 1.0;
            const double exp_delta_j = positions[j] * delta_x[j] * wj;
            const double exp_gamma_j = positions[j] * gamma_x[j] * wj;
            const double corr = corr_row[j];

            row_delta += corr * exp_delta_j;
            row_gamma += corr * exp_gamma_j;
        }

        net_delta += exp_delta_i * row_delta;
        net_gamma += exp_gamma_i * row_gamma;
    }

    *out_net_delta = net_delta;
    *out_net_gamma = net_gamma;
}
#endif

void aggregate_portfolio_greeks(
    const double *positions,
    const double *delta_x,
    const double *gamma_x,
    const double *weights,
    const double *corr_matrix,
    size_t n,
    double *out_net_delta,
    double *out_net_gamma
) {
    if (analytics_runtime_has_avx512()) {
#if PM_ANALYTICS_HAS_AVX512_DISPATCH
        pm_internal_aggregate_portfolio_greeks_avx512(
            positions,
            delta_x,
            gamma_x,
            weights,
            corr_matrix,
            n,
            out_net_delta,
            out_net_gamma
        );
        return;
#endif
    }

    pm_internal_aggregate_portfolio_greeks_portable(
        positions,
        delta_x,
        gamma_x,
        weights,
        corr_matrix,
        n,
        out_net_delta,
        out_net_gamma
    );
}
