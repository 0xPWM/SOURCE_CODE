#include "ring_buffer.h"

#include <stddef.h>

static inline int spsc_is_power_of_two_u64(uint64_t v) {
    return (v != 0u) && ((v & (v - 1u)) == 0u);
}

_Static_assert(sizeof(_Atomic uint64_t) <= SPSC_CACHELINE_SIZE,
               "atomic index must fit in one cache line");
_Static_assert(offsetof(spsc_ring_buffer_t, head) % SPSC_CACHELINE_SIZE == 0u,
               "head must be cacheline aligned");
_Static_assert(offsetof(spsc_ring_buffer_t, tail) % SPSC_CACHELINE_SIZE == 0u,
               "tail must be cacheline aligned");

int spsc_ring_buffer_init(spsc_ring_buffer_t *rb, l2_update_t *slots, uint64_t capacity) {
    if (rb == NULL || slots == NULL) {
        return 0;
    }
    if (capacity < 2u || !spsc_is_power_of_two_u64(capacity)) {
        return 0;
    }

    atomic_init(&rb->head, 0u);
    atomic_init(&rb->tail, 0u);
    rb->cached_tail = 0u;
    rb->cached_head = 0u;
    rb->slots = slots;
    rb->capacity = capacity;
    rb->mask = capacity - 1u;

    return 1;
}

int spsc_ring_buffer_push(spsc_ring_buffer_t *rb, const l2_update_t *msg) {
    if (rb == NULL || msg == NULL) {
        return 0;
    }

    /* head is producer-owned, so a relaxed load is enough. The consumer's tail
       is only re-read (acquire) when the cached snapshot says the ring is full. */
    const uint64_t head = atomic_load_explicit(&rb->head, memory_order_relaxed);

    if ((head - rb->cached_tail) >= rb->capacity) {
        rb->cached_tail = atomic_load_explicit(&rb->tail, memory_order_acquire);
        if ((head - rb->cached_tail) >= rb->capacity) {
            return 0;
        }
    }

    rb->slots[head & rb->mask] = *msg;
    atomic_store_explicit(&rb->head, head + 1u, memory_order_release);

    return 1;
}

int spsc_ring_buffer_pop(spsc_ring_buffer_t *rb, l2_update_t *out) {
    if (rb == NULL || out == NULL) {
        return 0;
    }

    /* tail is consumer-owned; only touch the producer's head line when the
       cached snapshot says the ring is empty. */
    const uint64_t tail = atomic_load_explicit(&rb->tail, memory_order_relaxed);

    if (tail == rb->cached_head) {
        rb->cached_head = atomic_load_explicit(&rb->head, memory_order_acquire);
        if (tail == rb->cached_head) {
            return 0;
        }
    }

    *out = rb->slots[tail & rb->mask];
    atomic_store_explicit(&rb->tail, tail + 1u, memory_order_release);

    return 1;
}

uint64_t spsc_ring_buffer_capacity(const spsc_ring_buffer_t *rb) {
    if (rb == NULL) {
        return 0u;
    }
    return rb->capacity;
}

uint64_t spsc_ring_buffer_len(const spsc_ring_buffer_t *rb) {
    if (rb == NULL) {
        return 0u;
    }

    const uint64_t head = atomic_load_explicit(&rb->head, memory_order_acquire);
    const uint64_t tail = atomic_load_explicit(&rb->tail, memory_order_acquire);
    return head - tail;
}

int spsc_ring_buffer_is_empty(const spsc_ring_buffer_t *rb) {
    return spsc_ring_buffer_len(rb) == 0u;
}

int spsc_ring_buffer_is_full(const spsc_ring_buffer_t *rb) {
    if (rb == NULL) {
        return 0;
    }
    return spsc_ring_buffer_len(rb) >= rb->capacity;
}
