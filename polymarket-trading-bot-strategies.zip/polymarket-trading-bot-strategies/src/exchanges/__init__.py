"""Exchange adapters and gateways"""

