"""Polymarket exchange adapter"""

