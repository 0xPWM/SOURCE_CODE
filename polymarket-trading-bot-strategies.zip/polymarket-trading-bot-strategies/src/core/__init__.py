"""Core trading bot components"""

